<?php
	include "usuarios.php";
?>
<html>
	<head>
		<title>Cadastro de Usuários</title>
	</head>
	<body>
		<b>
		<h1>Cadastro de Usuários</h1>
		<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			<H2>Nome: <input type="text" name="f_nome"></H2>
			<br/>
			<H2>Email: <input type="text" name="f_mail"></H2>
			<br/>
			<H2>Senha: <input type="password" name="f_senha"></H2>
			<br/>
			<input type="submit" value="Enviar">
		</form>
		<?php
			$myuser = new usuarios();
			if(isset($_POST['f_nome']) and isset($_POST['f_mail']) and isset($_POST['f_senha'])){
				$myuser->setNome($_POST['f_nome']);
				$myuser->setEmail($_POST['f_mail']);
				$myuser->setSenha($_POST['f_senha']);
				$myuser->insert();				
			}
			else {
				echo "Todos os campos são obrigatórios!";
			}
		?>
	<div>
		<table border=1>
		  <tr>
			<th width="20%">Nome</th>
			<th width="30%">Email</th>
		  </tr>
			<?php foreach($myuser->findAll() as $key=>$value):?>
		  <tr>		
			<td><?php echo "$value->nome";?></td>
			<td><?php echo "$value->email";?></td>
		  </tr>
			<?php endforeach;?>	
		</table>
	</div>
		
		</b>
	</body>
</html>