<?php
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'id12870088_banco1');
	define('DB_USER', 'id12870088_app');
	define('DB_PASS', 'app123');
?>
